<script setup>
import TheScan from "../components/TheScan.vue";
</script>
<template>
  <TheScan />
</template>

<style scoped></style>
